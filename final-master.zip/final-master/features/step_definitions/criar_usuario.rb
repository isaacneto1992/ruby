Quando('eu cadstro meu usuario') do
    user.load
    user.Preencher_usuario
    sleep(5)
  end
  
  Entao('verifico se o usuario foi cadastrado com sucesso') do
    
    @sucesso = find('#notice')
    expect(@sucesso.text).to eql 'Usuário Criado com sucesso'
  end